﻿namespace MyDatabase
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            buttonFaculty = new Button();
            buttonEnrolledSched = new Button();
            buttonEnrolledCourses = new Button();
            buttonCourses = new Button();
            label1 = new Label();
            SuspendLayout();
            // 
            // buttonFaculty
            // 
            buttonFaculty.Location = new Point(214, 145);
            buttonFaculty.Name = "buttonFaculty";
            buttonFaculty.Size = new Size(147, 23);
            buttonFaculty.TabIndex = 0;
            buttonFaculty.Text = "Faculty";
            buttonFaculty.UseVisualStyleBackColor = true;
            buttonFaculty.Click += OpenFacultyClick;
            // 
            // buttonEnrolledSched
            // 
            buttonEnrolledSched.Location = new Point(214, 174);
            buttonEnrolledSched.Name = "buttonEnrolledSched";
            buttonEnrolledSched.Size = new Size(147, 23);
            buttonEnrolledSched.TabIndex = 1;
            buttonEnrolledSched.Text = "Enrolled Schedule";
            buttonEnrolledSched.UseVisualStyleBackColor = true;
            // 
            // buttonEnrolledCourses
            // 
            buttonEnrolledCourses.Location = new Point(214, 203);
            buttonEnrolledCourses.Name = "buttonEnrolledCourses";
            buttonEnrolledCourses.Size = new Size(147, 23);
            buttonEnrolledCourses.TabIndex = 2;
            buttonEnrolledCourses.Text = "Enrolled Courses";
            buttonEnrolledCourses.UseVisualStyleBackColor = true;
            // 
            // buttonCourses
            // 
            buttonCourses.Location = new Point(214, 232);
            buttonCourses.Name = "buttonCourses";
            buttonCourses.Size = new Size(147, 23);
            buttonCourses.TabIndex = 3;
            buttonCourses.Text = "Courses";
            buttonCourses.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(242, 110);
            label1.Name = "label1";
            label1.Size = new Size(89, 15);
            label1.TabIndex = 5;
            label1.Text = "Choose a Entity";
            label1.Click += label1_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(513, 317);
            Controls.Add(label1);
            Controls.Add(buttonCourses);
            Controls.Add(buttonEnrolledCourses);
            Controls.Add(buttonEnrolledSched);
            Controls.Add(buttonFaculty);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button buttonFaculty;
        private Button buttonEnrolledSched;
        private Button buttonEnrolledCourses;
        private Button buttonCourses;
        private Label label1;
    }
}

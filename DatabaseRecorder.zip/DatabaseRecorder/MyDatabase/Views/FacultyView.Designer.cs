﻿namespace MyDatabase.Views
{
    partial class FacultyView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            FacultyIDtextBox = new TextBox();
            FacultyNametextBox = new TextBox();
            FacultyScheduletextBox = new TextBox();
            EnrolledCoursestextBox = new TextBox();
            label1 = new Label();
            label = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            Submitbutton = new Button();
            EraseAllbutton = new Button();
            SuspendLayout();
            // 
            // FacultyIDtextBox
            // 
            FacultyIDtextBox.Location = new Point(273, 163);
            FacultyIDtextBox.Name = "FacultyIDtextBox";
            FacultyIDtextBox.Size = new Size(195, 23);
            FacultyIDtextBox.TabIndex = 0;
            // 
            // FacultyNametextBox
            // 
            FacultyNametextBox.Location = new Point(273, 192);
            FacultyNametextBox.Name = "FacultyNametextBox";
            FacultyNametextBox.Size = new Size(195, 23);
            FacultyNametextBox.TabIndex = 1;
            // 
            // FacultyScheduletextBox
            // 
            FacultyScheduletextBox.Location = new Point(273, 221);
            FacultyScheduletextBox.Name = "FacultyScheduletextBox";
            FacultyScheduletextBox.Size = new Size(195, 23);
            FacultyScheduletextBox.TabIndex = 2;
            // 
            // EnrolledCoursestextBox
            // 
            EnrolledCoursestextBox.Location = new Point(272, 255);
            EnrolledCoursestextBox.Name = "EnrolledCoursestextBox";
            EnrolledCoursestextBox.Size = new Size(195, 23);
            EnrolledCoursestextBox.TabIndex = 3;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(171, 166);
            label1.Name = "label1";
            label1.Size = new Size(56, 15);
            label1.TabIndex = 4;
            label1.Text = "FacultyID";
            // 
            // label
            // 
            label.AutoSize = true;
            label.Location = new Point(171, 192);
            label.Name = "label";
            label.Size = new Size(80, 15);
            label.TabIndex = 5;
            label.Text = "Faculty Name";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(171, 229);
            label3.Name = "label3";
            label3.Size = new Size(96, 15);
            label3.TabIndex = 6;
            label3.Text = "Faculty Schedule";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(171, 258);
            label4.Name = "label4";
            label4.Size = new Size(95, 15);
            label4.TabIndex = 7;
            label4.Text = "Enrolled Courses";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(306, 126);
            label5.Name = "label5";
            label5.Size = new Size(102, 15);
            label5.TabIndex = 8;
            label5.Text = "Enter Faculty Data";
            // 
            // Submitbutton
            // 
            Submitbutton.Location = new Point(272, 305);
            Submitbutton.Name = "Submitbutton";
            Submitbutton.Size = new Size(75, 23);
            Submitbutton.TabIndex = 9;
            Submitbutton.Text = "Submit";
            Submitbutton.UseVisualStyleBackColor = true;
            Submitbutton.Click += AddFacultyClickAsync;
            // 
            // EraseAllbutton
            // 
            EraseAllbutton.Location = new Point(371, 305);
            EraseAllbutton.Name = "EraseAllbutton";
            EraseAllbutton.Size = new Size(75, 23);
            EraseAllbutton.TabIndex = 10;
            EraseAllbutton.Text = "Erase All";
            EraseAllbutton.UseVisualStyleBackColor = true;
            // 
            // FacultyView
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(EraseAllbutton);
            Controls.Add(Submitbutton);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label);
            Controls.Add(label1);
            Controls.Add(EnrolledCoursestextBox);
            Controls.Add(FacultyScheduletextBox);
            Controls.Add(FacultyNametextBox);
            Controls.Add(FacultyIDtextBox);
            Name = "FacultyView";
            Text = "FacultyView";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox FacultyIDtextBox;
        private TextBox FacultyNametextBox;
        private TextBox FacultyScheduletextBox;
        private TextBox EnrolledCoursestextBox;
        private Label label1;
        private Label label;
        private Label label3;
        private Label label4;
        private Label label5;
        private Button Submitbutton;
        private Button EraseAllbutton;
    }
}
﻿using DatabaseRecorder;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyDatabase.Views
{
    public partial class FacultyView : Form
    {
        public FacultyView()
        {
            InitializeComponent();
        }
        private static readonly HttpClient client = new HttpClient();
        private async void AddFacultyClickAsync(object sender, EventArgs e)
        {

            string FireBaseURL = "https://consultation-database-default-rtdb.firebaseio.com/";
            var Faculty = new Faculty()
            {
                FacultyName = FacultyNametextBox.Text,
                FacultyID =  int.Parse(FacultyIDtextBox.Text),
                FacultyScheduleID = 0,
                EnrolledCourseID = 0,
            };


            string json = System.Text.Json.JsonSerializer.Serialize(Faculty);
            var content = new StringContent(json, Encoding.UTF8, "application/json");

            var response = await client.PostAsync(FireBaseURL + "Faculty.json", content);

            if (response.IsSuccessStatusCode)
            {
                MessageBox.Show("Faculty added successfully");
            }
            else
            {
                string errorMessage = await response.Content.ReadAsStringAsync();
                MessageBox.Show($"Error adding faculty: {response.StatusCode}\n{errorMessage}");
            }
        }
    }
}
